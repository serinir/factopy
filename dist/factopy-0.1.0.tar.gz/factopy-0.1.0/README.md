# Factopy
[![codecov](https://codecov.io/gh/serinir/factopy/branch/main/graph/badge.svg?token=VWQAZUVBN1)](https://codecov.io/gh/serinir/factopy)
